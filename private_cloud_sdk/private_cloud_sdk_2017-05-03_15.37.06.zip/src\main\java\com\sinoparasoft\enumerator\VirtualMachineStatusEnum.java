package com.sinoparasoft.enumerator;

public enum VirtualMachineStatusEnum {
    BUILD, ACTIVE, STOPPED, ERROR, DELETED, UNKNOWN;
}
