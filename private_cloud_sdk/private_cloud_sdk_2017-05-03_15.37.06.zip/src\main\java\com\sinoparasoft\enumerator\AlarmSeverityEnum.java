package com.sinoparasoft.enumerator;

public enum AlarmSeverityEnum {

    LOWEST, BELOW_NORMAL, NORMAL, ABOVE_NORMAL, HIGHEST;
}
