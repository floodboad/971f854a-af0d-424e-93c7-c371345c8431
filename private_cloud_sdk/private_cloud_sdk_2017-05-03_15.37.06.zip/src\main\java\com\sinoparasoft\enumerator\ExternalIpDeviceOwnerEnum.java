package com.sinoparasoft.enumerator;

public enum ExternalIpDeviceOwnerEnum {

    FLOATING_IP, ROUTER_GATEWAY
}
