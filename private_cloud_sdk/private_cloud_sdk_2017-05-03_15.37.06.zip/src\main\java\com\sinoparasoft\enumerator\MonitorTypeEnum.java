package com.sinoparasoft.enumerator;

public enum MonitorTypeEnum {

    NODE, SERVICE, LOAD
}
