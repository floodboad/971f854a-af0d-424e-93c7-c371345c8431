package com.sinoparasoft.enumerator;

public enum OperationStatusEnum {
	OK, FAILED
}
