package com.sinoparasoft.enumerator;

public enum ExternalIpStatusEnum {

    AVAILABLE, IN_USE, UNKNOWN
}
