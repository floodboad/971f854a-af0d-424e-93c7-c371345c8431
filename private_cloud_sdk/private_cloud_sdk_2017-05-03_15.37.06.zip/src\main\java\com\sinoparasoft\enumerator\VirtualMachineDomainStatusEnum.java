package com.sinoparasoft.enumerator;

public enum VirtualMachineDomainStatusEnum {

    ENABLED, DISABLED, DELETED
}
