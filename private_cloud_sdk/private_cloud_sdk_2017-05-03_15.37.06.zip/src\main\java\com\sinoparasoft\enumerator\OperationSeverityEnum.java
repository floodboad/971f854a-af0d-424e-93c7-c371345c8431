package com.sinoparasoft.enumerator;

public enum OperationSeverityEnum {

    LOW, MIDDLE, HIGH;
}
