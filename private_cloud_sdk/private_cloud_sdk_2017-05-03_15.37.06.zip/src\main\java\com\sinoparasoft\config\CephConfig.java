package com.sinoparasoft.config;

public class CephConfig {
	private String restApiUrl;

	public String getRestApiUrl() {
		return restApiUrl;
	}

	public void setRestApiUrl(String restApiUrl) {
		this.restApiUrl = restApiUrl;
	}
}
