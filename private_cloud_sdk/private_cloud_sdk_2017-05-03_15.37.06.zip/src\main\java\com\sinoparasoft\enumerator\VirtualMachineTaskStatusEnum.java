package com.sinoparasoft.enumerator;

public enum VirtualMachineTaskStatusEnum {

    NONE, SPAWNING, POWERING_ON, POWERING_OFF, REBOOTING, DELETING, SNAPSHOTING, RESTORING_SNAPSHOT, MIGRATING
}
