package com.sinoparasoft.enumerator;

public enum PhysicalMachineTypeNameEnum {

    CONTROLLER_NODE, NETWORK_NODE, COMPUTE_NODE;
}
