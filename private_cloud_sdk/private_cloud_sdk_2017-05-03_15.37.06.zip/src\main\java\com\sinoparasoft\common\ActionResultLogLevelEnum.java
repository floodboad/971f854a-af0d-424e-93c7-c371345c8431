package com.sinoparasoft.common;

public enum ActionResultLogLevelEnum {
	WARN, ERROR, NONE
}
