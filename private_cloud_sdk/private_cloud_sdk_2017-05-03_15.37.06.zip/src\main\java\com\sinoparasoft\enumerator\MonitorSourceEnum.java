package com.sinoparasoft.enumerator;

public enum MonitorSourceEnum {

    PHYSICAL_MACHINE, VIRTUAL_MACHINE;
}
