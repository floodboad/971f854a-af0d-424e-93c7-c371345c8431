package com.sinoparasoft.enumerator;

public enum PhysicalMachineStatusEnum {
    ACTIVE, SHUTDOWN
}
