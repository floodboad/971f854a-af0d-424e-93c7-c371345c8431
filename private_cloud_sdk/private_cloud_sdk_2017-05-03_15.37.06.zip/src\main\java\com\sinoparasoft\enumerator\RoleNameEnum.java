package com.sinoparasoft.enumerator;

public enum RoleNameEnum {

    ROLE_NONE, ROLE_ADMIN, ROLE_MANAGER, ROLE_USER
}
