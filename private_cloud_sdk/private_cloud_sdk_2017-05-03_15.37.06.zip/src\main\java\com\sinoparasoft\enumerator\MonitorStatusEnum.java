package com.sinoparasoft.enumerator;

public enum MonitorStatusEnum {
    NORMAL, WARNING, UNKNOWN
}
