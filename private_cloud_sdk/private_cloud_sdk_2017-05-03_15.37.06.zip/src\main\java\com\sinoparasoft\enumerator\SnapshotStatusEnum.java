package com.sinoparasoft.enumerator;

public enum SnapshotStatusEnum {
    SAVING, ACTIVE, DELETING, DELETED, UNKNOWN, ERROR
}
