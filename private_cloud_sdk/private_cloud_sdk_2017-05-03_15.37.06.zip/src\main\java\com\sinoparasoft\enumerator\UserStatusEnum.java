package com.sinoparasoft.enumerator;

public enum UserStatusEnum {

    ENABLED, DISABLED, DELETED
}
