package com.sinoparasoft.enumerator;

public enum VirtualMachineGroupStatusEnum {

    ENABLED, DISABLED, DELETED
}
