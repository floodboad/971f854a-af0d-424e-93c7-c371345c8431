package com.sinoparasoft.enumerator;

public enum DiskStatusEnum {
	CREATING, AVAILABLE, ATTACHING, ATTACHED, DETATCHING, DELETING, DELETED, ERROR, UNKNOWN
}
